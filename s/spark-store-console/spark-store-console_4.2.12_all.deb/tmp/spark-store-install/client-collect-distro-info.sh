#!/bin/bash

# Get the OS distribution information
output=$(lsb_release --all)

# Extract Distributor ID and Release information
distributor_id=""
release=""
while IFS= read -r line; do
    if [[ $line == *"Distributor ID:"* ]]; then
        distributor_id=$(echo "$line" | awk -F ':' '{print $2}' | tr -s '[:space:]')
    elif [[ $line == *"Release:"* ]]; then
        release=$(echo "$line" | awk -F ':' '{print $2}' | tr -s '[:space:]')
    fi
done <<< "$output"

# Get the system architecture
architecture=$(uname -m)
UUID=$(uuidgen)
distributor_id=$(echo "$distributor_id" | tr -d '[:space:]')
release=$(echo "$release" | tr -d '[:space:]')
# Create a JSON string to store the information
info="{\"Distributor ID\": \"$distributor_id\", \"Release\": \"$release\",\"UUID\": \"$UUID\", \"Architecture\": \"$architecture\"}"

# Use Curl to send the information to the server's HTTP endpoint with the correct Content-Type header
echo $info
curl -X POST -H "Content-Type: application/json" -d "$info" https://status.deepinos.org.cn/upload

