package xeventmonitor

type CoordinateRange struct {
	X1, Y1, X2, Y2 int32
}
