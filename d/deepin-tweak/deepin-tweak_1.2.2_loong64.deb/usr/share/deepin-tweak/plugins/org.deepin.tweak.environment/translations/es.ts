<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es">
<context>
    <name>main</name>
    <message>
        <location filename="../main.qml" line="16"/>
        <source>System Environment</source>
        <translation>Entorno del sistema</translation>
    </message>
    <message>
        <location filename="../main.qml" line="17"/>
        <source>change system environment for user</source>
        <translation>cambiar el entorno del sistema para el usuario</translation>
    </message>
    <message>
        <location filename="../main.qml" line="117"/>
        <source>Please modify environment variables carefully.You must clearly understand the importance of system environment variables. This operation is irreversible.If there is a problem, please log in with tty and delete the $HOME/.dde_env file to restore the environment. Please login again to apply changes.</source>
        <translation>Por favor, modifique las variables de entorno con cuidado.Debe entender claramente la importancia de las variables de entorno del sistema. Si se produce algún problema, inicie sesión con tty y elimine el archivo $HOME/.dde_env para restaurar el entorno. Vuelva a iniciar la sesión para aplicar los cambios.</translation>
    </message>
    <message>
        <location filename="../main.qml" line="126"/>
        <source>Add</source>
        <translation>Añadir</translation>
    </message>
    <message>
        <location filename="../main.qml" line="145"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
</context>
</TS>
