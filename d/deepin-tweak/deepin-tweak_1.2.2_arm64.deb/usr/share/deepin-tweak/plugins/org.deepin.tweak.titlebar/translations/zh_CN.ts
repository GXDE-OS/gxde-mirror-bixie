<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>main</name>
    <message>
        <location filename="../main.qml" line="15"/>
        <source>Title height</source>
        <translation>标题栏高度</translation>
    </message>
    <message>
        <location filename="../main.qml" line="16"/>
        <source>Change window title height</source>
        <translation>修改标题栏高度</translation>
    </message>
    <message>
        <location filename="../main.qml" line="78"/>
        <source>Reset to default</source>
        <translation>重置为默认值</translation>
    </message>
    <message>
        <location filename="../main.qml" line="92"/>
        <source>Apply</source>
        <translation>应用</translation>
    </message>
</context>
</TS>
