#!/bin/sh

# /var/cache/apt/archives
# /var/lib/apt/lists ~ 181M
# /var/cache/apt/pkgcache.bin /var/cache/apt/srcpkgcache.bin ~ 181M
# /var/lib/lastore/safecache ~ 200M

# size calculate
pathList="";
if [ ! -d /target/var/lib/apt/lists ]; then
	printf "/var/lib/apt/lists not found !.\n" ; 
else
     pathList="${pathList} /target/var/lib/apt/lists"
fi
if [ ! -d /target/var/cache/apt/archives ]; then
	printf "/var/cache/apt/archives not found !.\n" ; 
else
     pathList="${pathList} /target/var/cache/apt/archives"
fi
if [ ! -d /target/var/lib/lastore/safecache ]; then
	printf "/var/lib/lastore/safecache not found !.\n" ; 
else
     pathList="${pathList} /target/var/lib/lastore/safecache"
fi

TOTAL_SIZE=$(LC_ALL=C find $pathList  -type f -not -name lock -exec du -ch {} + | grep total)
if [ -z ${TOTAL_SIZE} ]; then
        rm -rf /target/var/cache/apt/archives/*
        rm -rf /target/var/lib/apt/lists/*
	printf "Exit: Already DiskClean.\n" ; exit 0
fi

printf "DiskClean: %s\n" ${TOTAL_SIZE}
LC_ALL=C find $pathList -type f -not -name lock -exec rm -vf {} +
rm -rf /target/var/cache/apt/archives/*
rm -rf /target/var/lib/apt/lists/*
