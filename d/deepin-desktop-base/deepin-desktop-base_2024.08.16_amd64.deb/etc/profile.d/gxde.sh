#!/bin/bash
cd /tmp
export PATH=$PATH:/sbin
export QT_QPA_PLATFORMTHEME=deepin