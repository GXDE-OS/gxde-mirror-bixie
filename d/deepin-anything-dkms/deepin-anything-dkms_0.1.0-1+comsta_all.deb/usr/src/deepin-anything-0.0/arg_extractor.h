#pragma once

unsigned long get_arg(struct pt_regs* regs, int n);

