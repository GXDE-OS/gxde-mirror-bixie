#define DTK_VERSION_MAJOR 2
#define DTK_VERSION_MINOR 0
#define DTK_VERSION_PATCH 16
#define DTK_VERSION_BUILD 1
#define DTK_VERSION_STR "2.0.16.1"
//
#define DTKCORE_CLASS_DObject
#define DTKCORE_CLASS_DObjectPrivate
#define DTKCORE_CLASS_DSingleton
#define DTKCORE_CLASS_DUtil
#define DTKCORE_CLASS_DPinyin
#define DTKCORE_CLASS_DDBusSender
#define DTKCORE_CLASS_DRecentManager
#define DTKCORE_CLASS_DNotifySender
#define DTKCORE_CLASS_DLog
#define DTKCORE_CLASS_DFileWatcher
#define DTKCORE_CLASS_DBaseFileWatcher
#define DTKCORE_CLASS_DFileSystemWatcher
#define DTKCORE_CLASS_DFileWatcherManager
#define DTKCORE_CLASS_DPathBuf
#define DTKCORE_CLASS_DStandardPaths
#define DTKCORE_CLASS_DSettings
#define DTKCORE_CLASS_DSettingsGroup
#define DTKCORE_CLASS_DSettingsOption
