#define DTK_VERSION_MAJOR 15
#define DTK_VERSION_MINOR 11
#define DTK_VERSION_PATCH 20161
#define DTK_VERSION_BUILD 0
#define DTK_VERSION_STR "15.11.20161"
//
#define DTKCORE_CLASS_DObject
#define DTKCORE_CLASS_DObjectPrivate
#define DTKCORE_CLASS_DSingleton
#define DTKCORE_CLASS_DUtil
#define DTKCORE_CLASS_DPinyin
#define DTKCORE_CLASS_DDBusSender
#define DTKCORE_CLASS_DRecentManager
#define DTKCORE_CLASS_DNotifySender
#define DTKCORE_CLASS_DLog
#define DTKCORE_CLASS_DFileWatcher
#define DTKCORE_CLASS_DBaseFileWatcher
#define DTKCORE_CLASS_DFileSystemWatcher
#define DTKCORE_CLASS_DFileWatcherManager
#define DTKCORE_CLASS_DPathBuf
#define DTKCORE_CLASS_DStandardPaths
#define DTKCORE_CLASS_DSettings
#define DTKCORE_CLASS_DSettingsGroup
#define DTKCORE_CLASS_DSettingsOption
