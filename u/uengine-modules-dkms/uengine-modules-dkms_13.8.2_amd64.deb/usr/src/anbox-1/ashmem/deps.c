#include <linux/slab.h>
#include <linux/spinlock.h>
#include <linux/kallsyms.h>
#include <linux/version.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/kprobes.h>

#include <linux/seq_file.h>

#define KPROBE_PRE_HANDLER(fname) static int __kprobes fname(struct kprobe *p, struct pt_regs *regs)

typedef unsigned long (*lookup_symbol_address_fp)(const char *name);
static lookup_symbol_address_fp lookup_symbol_address_ = NULL;

long unsigned int kln_addr = 0;
static struct kprobe kp0, kp1;

KPROBE_PRE_HANDLER(handler_pre0)
{
  kln_addr = (--regs->ip);
  return 0;
}

KPROBE_PRE_HANDLER(handler_pre1)
{
  return 0;
}

static int do_register_kprobe(struct kprobe *kp, char *symbol_name, void *handler)
{
  int ret;
  
  kp->symbol_name = symbol_name;
  kp->pre_handler = handler;
  
  ret = register_kprobe(kp);
  if (ret < 0) {
    pr_err("register_probe() for symbol %s failed, returned %d\n", symbol_name, ret);
    return ret;
  }
  
  pr_info("Planted kprobe for symbol %s at %p\n", symbol_name, kp->addr);
  
  return ret;
}

void init_kallsyms_lookup_name(void)
{
  int ret;
  
  pr_info("module loaded\n");
  
  ret = do_register_kprobe(&kp0, "kallsyms_lookup_name", handler_pre0);
  if (ret < 0)
    return ret;
 
  ret = do_register_kprobe(&kp1, "kallsyms_lookup_name", handler_pre1);
  if (ret < 0) {
    unregister_kprobe(&kp0);
    return ret;
  }
  
  unregister_kprobe(&kp0);
  unregister_kprobe(&kp1);
  
  pr_info("kallsyms_lookup_name address = 0x%lx\n", kln_addr);
  
  lookup_symbol_address_ = (lookup_symbol_address_fp)kln_addr;
}

static int (*shmem_zero_setup_ptr)(struct vm_area_struct *) = NULL;

int shmem_zero_setup(struct vm_area_struct *vma)
{
	if (!shmem_zero_setup_ptr)
		shmem_zero_setup_ptr = lookup_symbol_address_("shmem_zero_setup");
	return shmem_zero_setup_ptr(vma);
}
